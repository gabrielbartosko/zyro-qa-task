In order to preview close Chrome and execute this in cmd:
c:\path\to\chrome.exe --allow-file-access-from-files "C:\path\to\allure-report-preview\index.html"